function generatePDF(){
    const element = document.getElementById("stuff2");
    html2pdf()
    .from(element)
    .save();
    console.log("Succesful!!")
}

